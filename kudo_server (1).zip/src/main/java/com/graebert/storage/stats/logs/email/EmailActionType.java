package com.graebert.storage.stats.logs.email;

public enum EmailActionType {
  THUMBNAIL_ACCESSED,
  FILE_LINK_OPENED
}

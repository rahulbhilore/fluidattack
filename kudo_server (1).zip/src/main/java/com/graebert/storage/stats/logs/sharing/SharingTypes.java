package com.graebert.storage.stats.logs.sharing;

public enum SharingTypes {
  PUBLIC_LINK,
  EMAIL_SHARE
}

package com.graebert.storage.stats.logs.storage;

public enum StorageActions {
  CONNECT,
  DISCONNECT
}

package com.graebert.storage.stats.logs.subscription;

public enum SubscriptionActions {
  SUBSCRIBED_MANUALLY,
  UNSUBSCRIBED_MANUALLY,
  SUBSCRIBED_AUTOMATICALLY,
  UNSUBSCRIBED_AUTOMATICALLY,
  SUBSCRIPTION_UPDATE
}

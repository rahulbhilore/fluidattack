package com.graebert.storage.stats.logs.sharing;

public enum SharingActions {
  LINK_CREATED,
  LINK_UPDATED,
  LINK_DELETED,
  LINK_ACCESSED,
  SHARED_BY_EMAIL,
  UNSHARED,
  LINK_DELETED_UNSAFELY
}

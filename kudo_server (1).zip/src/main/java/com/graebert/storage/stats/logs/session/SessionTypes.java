package com.graebert.storage.stats.logs.session;

public enum SessionTypes {
  FLUORINE_SESSION,
  XENON_SESSION
}

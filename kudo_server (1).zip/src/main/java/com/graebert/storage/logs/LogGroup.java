package com.graebert.storage.logs;

public enum LogGroup {
  UNNAMED,
  CONFLICTING_FILE,
  XRAY
}

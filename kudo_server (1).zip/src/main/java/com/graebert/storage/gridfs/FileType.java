package com.graebert.storage.gridfs;

public enum FileType {
  //    VERSION,
  SNAPSHOT,
  UNDO,
  BASECONTENT,
  DIFF
}

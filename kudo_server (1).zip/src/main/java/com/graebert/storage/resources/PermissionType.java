package com.graebert.storage.resources;

public enum PermissionType {
  UPLOAD,
  UPDATE,
  DELETE,
  SHARE,
  UNSHARE,
  CREATE
}

package com.graebert.storage.Entities;

public enum CollaboratorType {
  EDITOR,
  VIEWER
}

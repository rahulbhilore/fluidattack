package com.graebert.storage.storage.object.folder;

public class FolderEntity {}

package com.graebert.storage.storage.object.file;

public class FileEntity {}
